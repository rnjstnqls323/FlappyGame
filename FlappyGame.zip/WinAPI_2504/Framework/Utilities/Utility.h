#pragma once

class Utility
{
public:
	static vector<string> SplitString(string origin, string tok);
};